ICSE 22 Policy Dataset
======================

Overview
========
This folder contains the AWS policies we obtained from 
AWS forums, the AWS policies we synthesized by mutation,
and the Azure policies we obtained from the Microsoft Docs. 
It also contains each policy's translation, as was produced
by QUACKY. These translations can be run with latest version 
of ABC.

Contents
========
- policies: contains the policies, in JSON. For Azure,
  the role definitions and role assignments are also
  included.
- translations_baseline: contains the SMT translations
  of each policy, WITHOUT the action mapping and WITHOUT
  type constraints.
- translations_baseline_with_type: contains the SMT
  translations of each policy, WITHOUT the action mapping
  and WITH type constraints.
- translations_mapped: contains the SMT translations
  of each policy, WITH the action mapping and WITHOUT
  type constraints.
- translations_mapped_with_type: contains the SMT
  translations of each policy, WITH the action mapping
  and WITH type constraints.

For example, the policy "s3_object_query_permissions/fix.json"
can be found at

"./policies/s3_object_query_permissions/fix.json".

The corresponding SMT translation without the action 
mapping and without type constraints can be found at

"./translations_baseline/s3_object_query_permissions/fix/output_1.smt2".

Mutants
=======
The mutants can be found under "mutants" in each of
the subfolders above. For example, the mutant policy
"s3_object_query_permissions/fix/2_.json" is a mutant
of "s3_object_query_permissions/fix.json" and can be
found at

"./policies/mutants/s3_object_query_permissions/fix/2_.json".

The corresponding SMT translation without the action 
mapping and without type constraints can be found at

"./translations_baseline/mutants/s3_object_query_permissions/fix/2_/output_1.smt2".

Opening SMT translations in a text editor
=========================================
We recommend using Visual Studio Code to open SMT 
translations. When doing so, you may get a warning
that "the file is not displayed in the editor because
it is either binary or uses an unsupported text
encoding." In that case, click "Do you want to open
it anyway?" and then click "Text Editor".

Running ABC
===========
To run a translation on ABC, "cd" into the translation's
subfolder and then invoke ABC like below:

"abc -i output_1.smt -bs <bound> -v 0 --count-tuple --count-variable principal,action,resource".